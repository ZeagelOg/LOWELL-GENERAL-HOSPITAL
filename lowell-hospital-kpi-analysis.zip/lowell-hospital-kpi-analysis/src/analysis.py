# =============================================================================
# Lowell General Hospital — KPI Analysis (2020–2024)
# Author: Lisha Bhowmik | BBA Graduate · Data & Business Analyst
#
# This script loads monthly hospital data, calculates KPI summaries,
# runs statistical correlation analysis, and produces 7 publication-ready charts.
# =============================================================================

# If running in Jupyter Notebook, keep the line below.
# If using a plain Python script, you may remove it.
%matplotlib inline

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# 1. CONFIGURATION — set your paths and color palette here
# =============================================================================

SAVE_DIR = r'C:\Users\USER\Downloads\Archive\Archive\HealthCare_Project\HEALTH_CARE_PROJECT'
FILE_PATH = os.path.join(SAVE_DIR, '2.RAW_DATA.xlsx')

os.makedirs(SAVE_DIR, exist_ok=True)

COLORS = {
    'navy':     '#0D2137',
    'teal':     '#028090',
    'mint':     '#02C39A',
    'orange':   '#F4845F',
    'gray':     '#64748B',
    'white':    'white',
    'red':      '#C0392B',
    'light_bg': '#F0F7F9',
}

plt.rcParams.update({
    'font.family':          'sans-serif',
    'axes.spines.top':      False,
    'axes.spines.right':    False,
    'axes.facecolor':       '#F8FBFC',
    'figure.facecolor':     'white',
})

# =============================================================================
# 2. LOAD & CLEAN DATA
# =============================================================================

print("Loading data...")

df_raw = pd.read_excel(FILE_PATH, sheet_name='Case Study Dataset', header=None)
df = df_raw.iloc[1:].copy()

df.columns = [
    '_drop',
    'Month',
    'Occupancy_Rate',
    'Unassisted_Fall_Rate',
    'Staff_Resp_Score',
    'Unassisted_Fall_Pct',
    'Staff_Resp_Score_Pct',
    'Benchmark',
]
df = df.drop(columns=['_drop'])
df = df[df['Month'] != 'Month'].dropna(subset=['Month'])
df['Month'] = pd.to_datetime(df['Month'], errors='coerce')
df = df.dropna(subset=['Month'])

df['Year']      = df['Month'].dt.year
df['MonthName'] = df['Month'].dt.strftime('%b')

for col in ['Occupancy_Rate', 'Unassisted_Fall_Rate',
            'Staff_Resp_Score', 'Unassisted_Fall_Pct', 'Staff_Resp_Score_Pct']:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# =============================================================================
# 3. YEARLY AGGREGATION
# =============================================================================

yearly = df.groupby('Year').agg(
    Occ     = ('Occupancy_Rate',     'mean'),
    Fall    = ('Unassisted_Fall_Rate','mean'),
    Resp    = ('Staff_Resp_Score',    'mean'),
    FallPct = ('Unassisted_Fall_Pct', 'mean'),
    RespPct = ('Staff_Resp_Score_Pct','mean'),
).round(4)

years = list(yearly.index)
print("Data loaded. Generating 7 charts...\n")

# =============================================================================
# CHART 1 — Bed Occupancy Bar Chart (2020–2024)
# Shows that the hospital operates near or above 95% capacity every year.
# =============================================================================

fig, ax = plt.subplots(figsize=(7, 4.5), facecolor='white')
bars = ax.bar(years, yearly['Occ'] * 100, color=COLORS['teal'], width=0.5, zorder=3)
ax.set_ylim(80, 105)
ax.set_ylabel('Occupancy Rate (%)', color=COLORS['gray'], fontsize=10)
ax.set_title('Average Licensed Bed Occupancy Rate (2020–2024)',
             fontsize=11, fontweight='bold', color=COLORS['navy'], pad=15)
for bar, val in zip(bars, yearly['Occ']):
    ax.text(bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 1.0,
            f'{val * 100:.0f}%',
            ha='center', va='bottom', fontsize=9, fontweight='bold', color=COLORS['navy'])
ax.tick_params(colors=COLORS['gray'])
ax.yaxis.grid(True, color='#E0EAEE', linewidth=0.7, zorder=0)
plt.tight_layout()
plt.savefig(os.path.join(SAVE_DIR, 'chart_occupancy.png'), dpi=150, bbox_inches='tight')
plt.show()
print("Chart 1 saved: chart_occupancy.png")

# =============================================================================
# CHART 2 — Staff Responsiveness vs. 65% Benchmark (2020–2024)
# Highlights years where the hospital fell below the national HCAHPS benchmark.
# =============================================================================

fig, ax = plt.subplots(figsize=(7, 4), facecolor='white')
ax.plot(years, yearly['Resp'],
        color=COLORS['teal'], marker='o', linewidth=2.5, markersize=6,
        label='Actual Score', zorder=3)
ax.axhline(y=65, color=COLORS['orange'], linewidth=2, linestyle='--',
           label='Benchmark (65)', zorder=2)
ax.fill_between(years, yearly['Resp'], 65,
                where=[v < 65 for v in yearly['Resp']],
                alpha=0.15, color=COLORS['red'], label='Below Benchmark')
ax.fill_between(years, yearly['Resp'], 65,
                where=[v >= 65 for v in yearly['Resp']],
                alpha=0.15, color=COLORS['mint'])
ax.set_ylim(55, 72)
ax.set_ylabel('Score (%)', color=COLORS['gray'], fontsize=10)
ax.set_title('Staff Responsiveness Top Box Score vs. Benchmark',
             fontsize=11, fontweight='bold', color=COLORS['navy'], pad=10)
for y, v in zip(years, yearly['Resp']):
    ax.text(y, v + 0.5, f'{v:.1f}%',
            ha='center', va='bottom', fontsize=9, fontweight='bold', color=COLORS['teal'])
ax.legend(fontsize=9, frameon=False)
ax.tick_params(colors=COLORS['gray'])
ax.yaxis.grid(True, color='#E0EAEE', linewidth=0.7, zorder=0)
plt.tight_layout()
plt.savefig(os.path.join(SAVE_DIR, 'chart_staff.png'), dpi=150, bbox_inches='tight')
plt.show()
print("Chart 2 saved: chart_staff.png")

# =============================================================================
# CHART 3 — Unassisted Fall Rate per 1,000 Patient Days (2020–2024)
# Tracks patient safety risk; peaks in 2022–23 align with lowest responsiveness.
# =============================================================================

fig, ax = plt.subplots(figsize=(7, 4.5), facecolor='white')
bars = ax.bar(years, yearly['Fall'], color=COLORS['orange'], width=0.5, zorder=3)
ax.set_ylim(0, yearly['Fall'].max() * 1.15)
ax.set_ylabel('Falls per 1,000 Patient Days', color=COLORS['gray'], fontsize=10)
ax.set_title('Unassisted Fall Rate per 1,000 Patient Days (2020–2024)',
             fontsize=11, fontweight='bold', color=COLORS['navy'], pad=15)
for bar, val in zip(bars, yearly['Fall']):
    ax.text(bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.05,
            f'{val:.2f}',
            ha='center', va='bottom', fontsize=9, fontweight='bold', color=COLORS['navy'])
ax.tick_params(colors=COLORS['gray'])
ax.yaxis.grid(True, color='#E0EAEE', linewidth=0.7, zorder=0)
plt.tight_layout()
plt.savefig(os.path.join(SAVE_DIR, 'chart_falls.png'), dpi=150, bbox_inches='tight')
plt.show()
print("Chart 3 saved: chart_falls.png")

# =============================================================================
# CHART 4 — All 3 KPIs Grouped Bar (2020–2024)
# Side-by-side view to show how all three metrics move in parallel.
# =============================================================================

fig, ax = plt.subplots(figsize=(9, 4.5), facecolor='white')
x, w = np.arange(len(years)), 0.25

b1 = ax.bar(x - w, yearly['Occ']     * 100, w, label='Avg Bed Occupancy Rate (%)',    color=COLORS['teal'],   zorder=3)
b2 = ax.bar(x,      yearly['FallPct'] * 100, w, label='Avg Unassisted Fall %',         color=COLORS['orange'], zorder=3)
b3 = ax.bar(x + w,  yearly['RespPct'] * 100, w, label='Avg Staff Responsiveness %',    color=COLORS['navy'],   zorder=3)

ax.set_xticks(x)
ax.set_xticklabels(years)
ax.set_ylabel('Value (%)', color=COLORS['gray'], fontsize=10)
ax.set_title('All 3 KPIs Over Time (2020–2024)',
             fontsize=11, fontweight='bold', color=COLORS['navy'], pad=10)
ax.set_ylim(0, 115)
ax.legend(fontsize=8.5, frameon=False, loc='upper right')
ax.yaxis.grid(True, color='#E0EAEE', linewidth=0.7, zorder=0)

def label_bars(bars_list):
    for bar in bars_list:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 1.5,
                f'{h:.0f}%', ha='center', va='bottom', fontsize=7, color=COLORS['navy'])

label_bars(b1); label_bars(b2); label_bars(b3)
plt.tight_layout()
plt.savefig(os.path.join(SAVE_DIR, 'chart_all_kpis.png'), dpi=150, bbox_inches='tight')
plt.show()
print("Chart 4 saved: chart_all_kpis.png")

# =============================================================================
# CHART 5 — Scatter: Unassisted Fall % vs Staff Responsiveness (Pearson r = −0.791)
# Each dot = one month. Shows strong negative correlation.
# =============================================================================

fig, ax = plt.subplots(figsize=(6, 4.5), facecolor='white')
x_vals = df['Unassisted_Fall_Pct']  * 100
y_vals = df['Staff_Resp_Score_Pct'] * 100
ax.scatter(x_vals, y_vals,
           color=COLORS['teal'], alpha=0.65, s=45,
           edgecolors='white', linewidth=0.5, zorder=3)
mask  = ~np.isnan(x_vals) & ~np.isnan(y_vals)
m, b, r, p, _ = stats.linregress(x_vals[mask], y_vals[mask])
x_line = np.linspace(x_vals[mask].min(), x_vals[mask].max(), 100)
ax.plot(x_line, m * x_line + b, color=COLORS['orange'], linewidth=2, zorder=4)
ax.set_xlabel('Unassisted Fall %', color=COLORS['gray'], fontsize=10)
ax.set_ylabel('Staff Responsiveness %', color=COLORS['gray'], fontsize=10)
ax.set_title(f'Fall % vs Staff Responsiveness\n(r = {r:.3f}, strong negative)',
             fontsize=10, fontweight='bold', color=COLORS['navy'])
ax.yaxis.grid(True, color='#E0EAEE', linewidth=0.7, zorder=0)
plt.tight_layout()
plt.savefig(os.path.join(SAVE_DIR, 'chart_scatter1.png'), dpi=150, bbox_inches='tight')
plt.show()
print("Chart 5 saved: chart_scatter1.png")

# =============================================================================
# CHART 6 — Scatter: Bed Occupancy % vs Unassisted Fall % (Pearson r = +0.700)
# Each dot = one month. Shows strong positive correlation.
# =============================================================================

fig, ax = plt.subplots(figsize=(6, 4.5), facecolor='white')
x_vals2 = df['Occupancy_Rate']       * 100
y_vals2 = df['Unassisted_Fall_Pct']  * 100
ax.scatter(x_vals2, y_vals2,
           color=COLORS['navy'], alpha=0.65, s=45,
           edgecolors='white', linewidth=0.5, zorder=3)
mask2 = ~np.isnan(x_vals2) & ~np.isnan(y_vals2)
m2, b2, r2, p2, _ = stats.linregress(x_vals2[mask2], y_vals2[mask2])
x_line2 = np.linspace(x_vals2[mask2].min(), x_vals2[mask2].max(), 100)
ax.plot(x_line2, m2 * x_line2 + b2, color=COLORS['orange'], linewidth=2, zorder=4)
ax.set_xlabel('Bed Occupancy Rate (%)', color=COLORS['gray'], fontsize=10)
ax.set_ylabel('Unassisted Fall %', color=COLORS['gray'], fontsize=10)
ax.set_title(f'Occupancy vs Unassisted Fall %\n(r = {r2:+.3f}, strong positive)',
             fontsize=10, fontweight='bold', color=COLORS['navy'])
ax.yaxis.grid(True, color='#E0EAEE', linewidth=0.7, zorder=0)
plt.tight_layout()
plt.savefig(os.path.join(SAVE_DIR, 'chart_scatter2.png'), dpi=150, bbox_inches='tight')
plt.show()
print("Chart 6 saved: chart_scatter2.png")

# =============================================================================
# CHART 7 — Seasonal Dual-Axis: Monthly Fall Rate & Staff Responsiveness
# Reveals which months are highest risk across all five years combined.
# =============================================================================

month_order = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
monthly = df.groupby('MonthName').agg(
    Avg_Fall = ('Unassisted_Fall_Rate', 'mean'),
    Avg_Resp = ('Staff_Resp_Score',      'mean'),
).reindex(month_order)

fig, ax1 = plt.subplots(figsize=(9, 4), facecolor='white')
ax1.bar(month_order, monthly['Avg_Fall'],
        color=COLORS['orange'], alpha=0.75, zorder=3, label='Avg Fall Rate (left)')
ax1.set_ylabel('Fall Rate per 1,000 Days', color=COLORS['orange'], fontsize=10)
max_fall = monthly['Avg_Fall'].max()
ax1.set_ylim(0, max_fall * 1.3 if pd.notna(max_fall) else 1)
ax1.tick_params(axis='y', labelcolor=COLORS['orange'])
ax1.set_facecolor('#F8FBFC')

ax2 = ax1.twinx()
ax2.plot(month_order, monthly['Avg_Resp'],
         color=COLORS['teal'], marker='o', linewidth=2.5, markersize=5,
         label='Staff Resp Score (right)', zorder=4)
ax2.set_ylabel('Staff Responsiveness Score', color=COLORS['teal'], fontsize=10)
min_resp, max_resp = monthly['Avg_Resp'].min(), monthly['Avg_Resp'].max()
if pd.notna(min_resp) and pd.notna(max_resp):
    ax2.set_ylim(min_resp * 0.95, max_resp * 1.05)
ax2.tick_params(axis='y', labelcolor=COLORS['teal'])

ax1.set_title('Seasonal Trends: Fall Rate & Staff Responsiveness by Month',
              fontsize=11, fontweight='bold', color=COLORS['navy'], pad=10)
ax1.set_xlabel('Month', fontsize=10, color=COLORS['gray'])
ax1.yaxis.grid(True, color='#E0EAEE', linewidth=0.7, zorder=0)

lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=8.5, frameon=False, loc='upper left')

plt.tight_layout()
plt.savefig(os.path.join(SAVE_DIR, 'chart_seasonal.png'), dpi=150, bbox_inches='tight')
plt.show()
print("Chart 7 saved: chart_seasonal.png")

print("\n✅ All 7 charts generated and saved to:", SAVE_DIR)
